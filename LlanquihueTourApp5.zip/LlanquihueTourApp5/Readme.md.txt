# LlanquihueTourApp5

## Descripción

LlanquihueTourApp5 es una aplicación desarrollada en Java que permite gestionar servicios turísticos de una agencia. El programa carga la información desde un archivo de texto, almacena los datos en una colección dinámica (`ArrayList`) y permite consultar los servicios disponibles mediante una búsqueda por nombre.

## Funcionalidades

- Carga de servicios turísticos desde un archivo `tours.txt`.
- Almacenamiento de datos utilizando `ArrayList`.
- Búsqueda de servicios por nombre.
- Organización del proyecto en paquetes.
- Uso de herencia, encapsulamiento y manejo de excepciones.

## Paquetes del proyecto

### app
- Main.java

### model
- ServicioTuristico.java
- RutaGastronomica.java
- PaseoLacustre.java
- ExcursionCultural.java

### service
- GestorServicios.java

### util
- LectorArchivo.java

## Requisitos

- Java JDK 17 o superior.
- Apache NetBeans.

## Cómo ejecutar

1. Abrir el proyecto en Apache NetBeans.
2. Verificar que el archivo `tours.txt` esté disponible.
3. Ejecutar la clase `Main.java`.
4. Ingresar el nombre del servicio para realizar una búsqueda.

## Autor

Vicente Estrada
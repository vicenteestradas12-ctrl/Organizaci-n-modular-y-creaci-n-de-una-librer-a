package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import model.ServicioTuristico;
import service.GestorServicios;

public class LectorArchivo {

    public static void cargarArchivo(String nombreArchivo, GestorServicios gestor) {

        try {

            InputStream archivo = LectorArchivo.class.getClassLoader()
                    .getResourceAsStream(nombreArchivo);

            if (archivo == null) {
                System.out.println("No se encontró el archivo: " + nombreArchivo);
                return;
            }

            BufferedReader lector = new BufferedReader(new InputStreamReader(archivo));

            String linea;

            while ((linea = lector.readLine()) != null) {

                String[] datos = linea.split(",");

                if (datos.length < 2) {
                    continue;
                }

                String nombre = datos[0].trim();
                int duracion = Integer.parseInt(datos[1].trim());

                gestor.agregarServicio(new ServicioTuristico(nombre, duracion));
            }

            lector.close();

            System.out.println("Servicios cargados: " + gestor.getServicios().size());

        } catch (IOException e) {
            System.out.println("Error al leer el archivo.");
        } catch (NumberFormatException e) {
            System.out.println("Error en el formato de los datos.");
        }
    }
}
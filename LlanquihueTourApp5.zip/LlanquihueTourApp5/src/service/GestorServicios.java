package service;

import java.util.ArrayList;
import model.ServicioTuristico;

public class GestorServicios {

    // Lista donde se almacenarán los servicios turísticos
    private ArrayList<ServicioTuristico> servicios;

    // Constructor
    public GestorServicios() {
        servicios = new ArrayList<>();
    }

    // Agregar un servicio
    public void agregarServicio(ServicioTuristico servicio) {
        servicios.add(servicio);
    }

    // Mostrar todos los servicios
    public void mostrarServicios() {

        if (servicios.isEmpty()) {
            System.out.println("No hay servicios registrados.");
        } else {
            for (ServicioTuristico servicio : servicios) {
                System.out.println(servicio);
            }
        }
    }

    // Buscar un servicio por nombre
    public ServicioTuristico buscarServicio(String nombre) {

        for (ServicioTuristico servicio : servicios) {

            if (servicio.getNombre().equalsIgnoreCase(nombre)) {
                return servicio;
            }

        }

        return null;
    }

    // Obtener la lista completa
    public ArrayList<ServicioTuristico> getServicios() {
        return servicios;
    }
}
package model;

public class PaseoLacustre extends ServicioTuristico {

    private boolean incluyeNavegacion;

    public PaseoLacustre() {
    }

    public PaseoLacustre(String nombre, int duracionHoras, boolean incluyeNavegacion) {
        super(nombre, duracionHoras);
        this.incluyeNavegacion = incluyeNavegacion;
    }

    public boolean isIncluyeNavegacion() {
        return incluyeNavegacion;
    }

    public void setIncluyeNavegacion(boolean incluyeNavegacion) {
        this.incluyeNavegacion = incluyeNavegacion;
    }

    @Override
    public String toString() {
        return super.toString() +
                ", Incluye navegación: " + incluyeNavegacion;
    }
}
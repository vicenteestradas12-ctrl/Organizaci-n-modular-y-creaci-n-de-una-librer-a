package model;

public class RutaGastronomica extends ServicioTuristico {

    // Atributo propio
    private String especialidad;

    // Constructor vacío
    public RutaGastronomica() {
    }

    // Constructor con parámetros
    public RutaGastronomica(String nombre, int duracionHoras, String especialidad) {
        super(nombre, duracionHoras);
        this.especialidad = especialidad;
    }

    // Getter
    public String getEspecialidad() {
        return especialidad;
    }

    // Setter
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    // Mostrar información
    @Override
    public String toString() {
        return super.toString() +
                ", Especialidad: " + especialidad;
    }
}
package app;

import java.util.Scanner;

import model.ServicioTuristico;
import service.GestorServicios;
import util.LectorArchivo;

public class Main {

    public static void main(String[] args) {

        // Crear el gestor de servicios
        GestorServicios gestor = new GestorServicios();

        // Cargar los datos desde el archivo
        LectorArchivo.cargarArchivo("tours.txt", gestor);

        // Mostrar todos los servicios
        System.out.println("\n===== SERVICIOS TURÍSTICOS =====");
        gestor.mostrarServicios();

        // Buscar un servicio
        Scanner teclado = new Scanner(System.in);

        System.out.print("\nIngrese el nombre del servicio que desea buscar: ");
        String nombre = teclado.nextLine();

        ServicioTuristico encontrado = gestor.buscarServicio(nombre);

        if (encontrado != null) {
            System.out.println("\nServicio encontrado:");
            System.out.println(encontrado);
        } else {
            System.out.println("\nEl servicio no existe.");
        }

        teclado.close();
    }
}